﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bx_kata_1 = new System.Windows.Forms.TextBox();
            this.bx_kata_2 = new System.Windows.Forms.TextBox();
            this.bx_kata_3 = new System.Windows.Forms.TextBox();
            this.bx_kata_4 = new System.Windows.Forms.TextBox();
            this.bx_kata_5 = new System.Windows.Forms.TextBox();
            this.lbl_1 = new System.Windows.Forms.Label();
            this.lbl_2 = new System.Windows.Forms.Label();
            this.lbl_4 = new System.Windows.Forms.Label();
            this.lbl_5 = new System.Windows.Forms.Label();
            this.lbl_3 = new System.Windows.Forms.Label();
            this.btn_play = new System.Windows.Forms.Button();
            this.pnl_tampilan = new System.Windows.Forms.Panel();
            this.pnl2_tampilan = new System.Windows.Forms.Panel();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_Z = new System.Windows.Forms.Button();
            this.btn_Q = new System.Windows.Forms.Button();
            this.btn_L = new System.Windows.Forms.Button();
            this.btn_O = new System.Windows.Forms.Button();
            this.btn_K = new System.Windows.Forms.Button();
            this.btn_i = new System.Windows.Forms.Button();
            this.btn_M = new System.Windows.Forms.Button();
            this.btn_J = new System.Windows.Forms.Button();
            this.btn_U = new System.Windows.Forms.Button();
            this.btn_N = new System.Windows.Forms.Button();
            this.btn_H = new System.Windows.Forms.Button();
            this.btn_Y = new System.Windows.Forms.Button();
            this.btn_B = new System.Windows.Forms.Button();
            this.btn_G = new System.Windows.Forms.Button();
            this.btn_T = new System.Windows.Forms.Button();
            this.btn_V = new System.Windows.Forms.Button();
            this.btn_F = new System.Windows.Forms.Button();
            this.btn_R = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.btn_D = new System.Windows.Forms.Button();
            this.btn_E = new System.Windows.Forms.Button();
            this.btn_X = new System.Windows.Forms.Button();
            this.btn_S = new System.Windows.Forms.Button();
            this.btn_W = new System.Windows.Forms.Button();
            this.btn_A = new System.Windows.Forms.Button();
            this.lbl_jawab5 = new System.Windows.Forms.Label();
            this.lbl_jawab4 = new System.Windows.Forms.Label();
            this.lbl_jawab3 = new System.Windows.Forms.Label();
            this.lbl_jawab2 = new System.Windows.Forms.Label();
            this.lbl_jawab1 = new System.Windows.Forms.Label();
            this.lbl_jawaban = new System.Windows.Forms.Label();
            this.pnl_tampilan.SuspendLayout();
            this.pnl2_tampilan.SuspendLayout();
            this.SuspendLayout();
            // 
            // bx_kata_1
            // 
            this.bx_kata_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bx_kata_1.Location = new System.Drawing.Point(255, 59);
            this.bx_kata_1.Name = "bx_kata_1";
            this.bx_kata_1.Size = new System.Drawing.Size(281, 44);
            this.bx_kata_1.TabIndex = 0;
            // 
            // bx_kata_2
            // 
            this.bx_kata_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bx_kata_2.Location = new System.Drawing.Point(255, 141);
            this.bx_kata_2.Name = "bx_kata_2";
            this.bx_kata_2.Size = new System.Drawing.Size(281, 44);
            this.bx_kata_2.TabIndex = 1;
            // 
            // bx_kata_3
            // 
            this.bx_kata_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bx_kata_3.Location = new System.Drawing.Point(255, 235);
            this.bx_kata_3.Name = "bx_kata_3";
            this.bx_kata_3.Size = new System.Drawing.Size(281, 44);
            this.bx_kata_3.TabIndex = 2;
            // 
            // bx_kata_4
            // 
            this.bx_kata_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bx_kata_4.Location = new System.Drawing.Point(255, 332);
            this.bx_kata_4.Name = "bx_kata_4";
            this.bx_kata_4.Size = new System.Drawing.Size(281, 44);
            this.bx_kata_4.TabIndex = 3;
            // 
            // bx_kata_5
            // 
            this.bx_kata_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bx_kata_5.Location = new System.Drawing.Point(255, 416);
            this.bx_kata_5.Name = "bx_kata_5";
            this.bx_kata_5.Size = new System.Drawing.Size(281, 44);
            this.bx_kata_5.TabIndex = 4;
            // 
            // lbl_1
            // 
            this.lbl_1.AutoSize = true;
            this.lbl_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_1.Location = new System.Drawing.Point(90, 65);
            this.lbl_1.Name = "lbl_1";
            this.lbl_1.Size = new System.Drawing.Size(100, 31);
            this.lbl_1.TabIndex = 5;
            this.lbl_1.Text = "Word 1";
            // 
            // lbl_2
            // 
            this.lbl_2.AutoSize = true;
            this.lbl_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_2.Location = new System.Drawing.Point(90, 154);
            this.lbl_2.Name = "lbl_2";
            this.lbl_2.Size = new System.Drawing.Size(100, 31);
            this.lbl_2.TabIndex = 6;
            this.lbl_2.Text = "Word 2";
            // 
            // lbl_4
            // 
            this.lbl_4.AutoSize = true;
            this.lbl_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_4.Location = new System.Drawing.Point(90, 338);
            this.lbl_4.Name = "lbl_4";
            this.lbl_4.Size = new System.Drawing.Size(100, 31);
            this.lbl_4.TabIndex = 8;
            this.lbl_4.Text = "Word 4";
            // 
            // lbl_5
            // 
            this.lbl_5.AutoSize = true;
            this.lbl_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_5.Location = new System.Drawing.Point(90, 422);
            this.lbl_5.Name = "lbl_5";
            this.lbl_5.Size = new System.Drawing.Size(100, 31);
            this.lbl_5.TabIndex = 9;
            this.lbl_5.Text = "Word 5";
            // 
            // lbl_3
            // 
            this.lbl_3.AutoSize = true;
            this.lbl_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_3.Location = new System.Drawing.Point(90, 248);
            this.lbl_3.Name = "lbl_3";
            this.lbl_3.Size = new System.Drawing.Size(100, 31);
            this.lbl_3.TabIndex = 10;
            this.lbl_3.Text = "Word 3";
            // 
            // btn_play
            // 
            this.btn_play.Location = new System.Drawing.Point(329, 494);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(127, 58);
            this.btn_play.TabIndex = 11;
            this.btn_play.Text = "PLAY";
            this.btn_play.UseVisualStyleBackColor = true;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // pnl_tampilan
            // 
            this.pnl_tampilan.Controls.Add(this.bx_kata_1);
            this.pnl_tampilan.Controls.Add(this.btn_play);
            this.pnl_tampilan.Controls.Add(this.bx_kata_2);
            this.pnl_tampilan.Controls.Add(this.lbl_3);
            this.pnl_tampilan.Controls.Add(this.bx_kata_3);
            this.pnl_tampilan.Controls.Add(this.lbl_5);
            this.pnl_tampilan.Controls.Add(this.bx_kata_4);
            this.pnl_tampilan.Controls.Add(this.lbl_4);
            this.pnl_tampilan.Controls.Add(this.bx_kata_5);
            this.pnl_tampilan.Controls.Add(this.lbl_2);
            this.pnl_tampilan.Controls.Add(this.lbl_1);
            this.pnl_tampilan.Location = new System.Drawing.Point(445, 842);
            this.pnl_tampilan.Name = "pnl_tampilan";
            this.pnl_tampilan.Size = new System.Drawing.Size(699, 577);
            this.pnl_tampilan.TabIndex = 12;
            // 
            // pnl2_tampilan
            // 
            this.pnl2_tampilan.Controls.Add(this.lbl_jawaban);
            this.pnl2_tampilan.Controls.Add(this.btn_P);
            this.pnl2_tampilan.Controls.Add(this.btn_Z);
            this.pnl2_tampilan.Controls.Add(this.btn_Q);
            this.pnl2_tampilan.Controls.Add(this.btn_L);
            this.pnl2_tampilan.Controls.Add(this.btn_O);
            this.pnl2_tampilan.Controls.Add(this.btn_K);
            this.pnl2_tampilan.Controls.Add(this.btn_i);
            this.pnl2_tampilan.Controls.Add(this.btn_M);
            this.pnl2_tampilan.Controls.Add(this.btn_J);
            this.pnl2_tampilan.Controls.Add(this.btn_U);
            this.pnl2_tampilan.Controls.Add(this.btn_N);
            this.pnl2_tampilan.Controls.Add(this.btn_H);
            this.pnl2_tampilan.Controls.Add(this.btn_Y);
            this.pnl2_tampilan.Controls.Add(this.btn_B);
            this.pnl2_tampilan.Controls.Add(this.btn_G);
            this.pnl2_tampilan.Controls.Add(this.btn_T);
            this.pnl2_tampilan.Controls.Add(this.btn_V);
            this.pnl2_tampilan.Controls.Add(this.btn_F);
            this.pnl2_tampilan.Controls.Add(this.btn_R);
            this.pnl2_tampilan.Controls.Add(this.btn_C);
            this.pnl2_tampilan.Controls.Add(this.btn_D);
            this.pnl2_tampilan.Controls.Add(this.btn_E);
            this.pnl2_tampilan.Controls.Add(this.btn_X);
            this.pnl2_tampilan.Controls.Add(this.btn_S);
            this.pnl2_tampilan.Controls.Add(this.btn_W);
            this.pnl2_tampilan.Controls.Add(this.btn_A);
            this.pnl2_tampilan.Controls.Add(this.lbl_jawab5);
            this.pnl2_tampilan.Controls.Add(this.lbl_jawab4);
            this.pnl2_tampilan.Controls.Add(this.lbl_jawab3);
            this.pnl2_tampilan.Controls.Add(this.lbl_jawab2);
            this.pnl2_tampilan.Controls.Add(this.lbl_jawab1);
            this.pnl2_tampilan.Location = new System.Drawing.Point(209, 59);
            this.pnl2_tampilan.Name = "pnl2_tampilan";
            this.pnl2_tampilan.Size = new System.Drawing.Size(1130, 688);
            this.pnl2_tampilan.TabIndex = 44;
            this.pnl2_tampilan.Visible = false;
            // 
            // btn_P
            // 
            this.btn_P.Location = new System.Drawing.Point(1026, 326);
            this.btn_P.Name = "btn_P";
            this.btn_P.Size = new System.Drawing.Size(62, 64);
            this.btn_P.TabIndex = 108;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = true;
            this.btn_P.Click += new System.EventHandler(this.btn_P_Click);
            // 
            // btn_Z
            // 
            this.btn_Z.Location = new System.Drawing.Point(81, 502);
            this.btn_Z.Name = "btn_Z";
            this.btn_Z.Size = new System.Drawing.Size(67, 64);
            this.btn_Z.TabIndex = 107;
            this.btn_Z.Text = "Z";
            this.btn_Z.UseVisualStyleBackColor = true;
            this.btn_Z.Click += new System.EventHandler(this.btn_Z_Click);
            // 
            // btn_Q
            // 
            this.btn_Q.Location = new System.Drawing.Point(40, 326);
            this.btn_Q.Name = "btn_Q";
            this.btn_Q.Size = new System.Drawing.Size(67, 64);
            this.btn_Q.TabIndex = 106;
            this.btn_Q.Text = "Q";
            this.btn_Q.UseVisualStyleBackColor = true;
            this.btn_Q.Click += new System.EventHandler(this.btn_Q_Click);
            // 
            // btn_L
            // 
            this.btn_L.Location = new System.Drawing.Point(938, 409);
            this.btn_L.Name = "btn_L";
            this.btn_L.Size = new System.Drawing.Size(62, 64);
            this.btn_L.TabIndex = 104;
            this.btn_L.Text = "L";
            this.btn_L.UseVisualStyleBackColor = true;
            this.btn_L.Click += new System.EventHandler(this.btn_L_Click);
            // 
            // btn_O
            // 
            this.btn_O.Location = new System.Drawing.Point(914, 326);
            this.btn_O.Name = "btn_O";
            this.btn_O.Size = new System.Drawing.Size(62, 64);
            this.btn_O.TabIndex = 103;
            this.btn_O.Text = "O";
            this.btn_O.UseVisualStyleBackColor = true;
            this.btn_O.Click += new System.EventHandler(this.btn_O_Click);
            // 
            // btn_K
            // 
            this.btn_K.Location = new System.Drawing.Point(828, 409);
            this.btn_K.Name = "btn_K";
            this.btn_K.Size = new System.Drawing.Size(62, 64);
            this.btn_K.TabIndex = 102;
            this.btn_K.Text = "K";
            this.btn_K.UseVisualStyleBackColor = true;
            this.btn_K.Click += new System.EventHandler(this.btn_K_Click);
            // 
            // btn_i
            // 
            this.btn_i.Location = new System.Drawing.Point(808, 326);
            this.btn_i.Name = "btn_i";
            this.btn_i.Size = new System.Drawing.Size(62, 64);
            this.btn_i.TabIndex = 101;
            this.btn_i.Text = "I";
            this.btn_i.UseVisualStyleBackColor = true;
            this.btn_i.Click += new System.EventHandler(this.btn_i_Click);
            // 
            // btn_M
            // 
            this.btn_M.Location = new System.Drawing.Point(738, 496);
            this.btn_M.Name = "btn_M";
            this.btn_M.Size = new System.Drawing.Size(62, 64);
            this.btn_M.TabIndex = 100;
            this.btn_M.Text = "M";
            this.btn_M.UseVisualStyleBackColor = true;
            this.btn_M.Click += new System.EventHandler(this.btn_M_Click);
            // 
            // btn_J
            // 
            this.btn_J.Location = new System.Drawing.Point(719, 409);
            this.btn_J.Name = "btn_J";
            this.btn_J.Size = new System.Drawing.Size(62, 64);
            this.btn_J.TabIndex = 99;
            this.btn_J.Text = "J";
            this.btn_J.UseVisualStyleBackColor = true;
            this.btn_J.Click += new System.EventHandler(this.btn_J_Click);
            // 
            // btn_U
            // 
            this.btn_U.Location = new System.Drawing.Point(701, 326);
            this.btn_U.Name = "btn_U";
            this.btn_U.Size = new System.Drawing.Size(62, 64);
            this.btn_U.TabIndex = 98;
            this.btn_U.Text = "U";
            this.btn_U.UseVisualStyleBackColor = true;
            this.btn_U.Click += new System.EventHandler(this.btn_U_Click);
            // 
            // btn_N
            // 
            this.btn_N.Location = new System.Drawing.Point(630, 499);
            this.btn_N.Name = "btn_N";
            this.btn_N.Size = new System.Drawing.Size(62, 64);
            this.btn_N.TabIndex = 97;
            this.btn_N.Text = "N";
            this.btn_N.UseVisualStyleBackColor = true;
            this.btn_N.Click += new System.EventHandler(this.btn_N_Click);
            // 
            // btn_H
            // 
            this.btn_H.Location = new System.Drawing.Point(609, 409);
            this.btn_H.Name = "btn_H";
            this.btn_H.Size = new System.Drawing.Size(62, 64);
            this.btn_H.TabIndex = 96;
            this.btn_H.Text = "H";
            this.btn_H.UseVisualStyleBackColor = true;
            this.btn_H.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_Y
            // 
            this.btn_Y.Location = new System.Drawing.Point(596, 326);
            this.btn_Y.Name = "btn_Y";
            this.btn_Y.Size = new System.Drawing.Size(62, 64);
            this.btn_Y.TabIndex = 95;
            this.btn_Y.Text = "Y";
            this.btn_Y.UseVisualStyleBackColor = true;
            this.btn_Y.Click += new System.EventHandler(this.btn_Y_Click);
            // 
            // btn_B
            // 
            this.btn_B.Location = new System.Drawing.Point(529, 499);
            this.btn_B.Name = "btn_B";
            this.btn_B.Size = new System.Drawing.Size(62, 64);
            this.btn_B.TabIndex = 94;
            this.btn_B.Text = "B";
            this.btn_B.UseVisualStyleBackColor = true;
            this.btn_B.Click += new System.EventHandler(this.btn_B_Click);
            // 
            // btn_G
            // 
            this.btn_G.Location = new System.Drawing.Point(507, 409);
            this.btn_G.Name = "btn_G";
            this.btn_G.Size = new System.Drawing.Size(62, 64);
            this.btn_G.TabIndex = 93;
            this.btn_G.Text = "G";
            this.btn_G.UseVisualStyleBackColor = true;
            this.btn_G.Click += new System.EventHandler(this.btn_G_Click);
            // 
            // btn_T
            // 
            this.btn_T.Location = new System.Drawing.Point(482, 326);
            this.btn_T.Name = "btn_T";
            this.btn_T.Size = new System.Drawing.Size(62, 64);
            this.btn_T.TabIndex = 92;
            this.btn_T.Text = "T";
            this.btn_T.UseVisualStyleBackColor = true;
            this.btn_T.Click += new System.EventHandler(this.btn_T_Click);
            // 
            // btn_V
            // 
            this.btn_V.Location = new System.Drawing.Point(424, 496);
            this.btn_V.Name = "btn_V";
            this.btn_V.Size = new System.Drawing.Size(62, 64);
            this.btn_V.TabIndex = 91;
            this.btn_V.Text = "V";
            this.btn_V.UseVisualStyleBackColor = true;
            this.btn_V.Click += new System.EventHandler(this.btn_V_Click);
            // 
            // btn_F
            // 
            this.btn_F.Location = new System.Drawing.Point(399, 409);
            this.btn_F.Name = "btn_F";
            this.btn_F.Size = new System.Drawing.Size(62, 64);
            this.btn_F.TabIndex = 90;
            this.btn_F.Text = "F";
            this.btn_F.UseVisualStyleBackColor = true;
            this.btn_F.Click += new System.EventHandler(this.btn_F_Click);
            // 
            // btn_R
            // 
            this.btn_R.Location = new System.Drawing.Point(367, 326);
            this.btn_R.Name = "btn_R";
            this.btn_R.Size = new System.Drawing.Size(62, 64);
            this.btn_R.TabIndex = 89;
            this.btn_R.Text = "R";
            this.btn_R.UseVisualStyleBackColor = true;
            this.btn_R.Click += new System.EventHandler(this.btn_R_Click);
            // 
            // btn_C
            // 
            this.btn_C.Location = new System.Drawing.Point(311, 496);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(65, 70);
            this.btn_C.TabIndex = 88;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = true;
            this.btn_C.Click += new System.EventHandler(this.btn_C_Click);
            // 
            // btn_D
            // 
            this.btn_D.Location = new System.Drawing.Point(284, 409);
            this.btn_D.Name = "btn_D";
            this.btn_D.Size = new System.Drawing.Size(65, 64);
            this.btn_D.TabIndex = 87;
            this.btn_D.Text = "D";
            this.btn_D.UseVisualStyleBackColor = true;
            this.btn_D.Click += new System.EventHandler(this.btn_D_Click);
            // 
            // btn_E
            // 
            this.btn_E.Location = new System.Drawing.Point(257, 326);
            this.btn_E.Name = "btn_E";
            this.btn_E.Size = new System.Drawing.Size(62, 64);
            this.btn_E.TabIndex = 86;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = true;
            this.btn_E.Click += new System.EventHandler(this.btn_E_Click);
            // 
            // btn_X
            // 
            this.btn_X.Location = new System.Drawing.Point(194, 496);
            this.btn_X.Name = "btn_X";
            this.btn_X.Size = new System.Drawing.Size(67, 70);
            this.btn_X.TabIndex = 85;
            this.btn_X.Text = "X";
            this.btn_X.UseVisualStyleBackColor = true;
            this.btn_X.Click += new System.EventHandler(this.btn_X_Click);
            // 
            // btn_S
            // 
            this.btn_S.Location = new System.Drawing.Point(170, 409);
            this.btn_S.Name = "btn_S";
            this.btn_S.Size = new System.Drawing.Size(63, 64);
            this.btn_S.TabIndex = 84;
            this.btn_S.Text = "S";
            this.btn_S.UseVisualStyleBackColor = true;
            this.btn_S.Click += new System.EventHandler(this.btn_S_Click);
            // 
            // btn_W
            // 
            this.btn_W.Location = new System.Drawing.Point(150, 326);
            this.btn_W.Name = "btn_W";
            this.btn_W.Size = new System.Drawing.Size(67, 64);
            this.btn_W.TabIndex = 83;
            this.btn_W.Text = "W";
            this.btn_W.UseVisualStyleBackColor = true;
            this.btn_W.Click += new System.EventHandler(this.btn_W_Click);
            // 
            // btn_A
            // 
            this.btn_A.Location = new System.Drawing.Point(61, 409);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(68, 64);
            this.btn_A.TabIndex = 81;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = true;
            this.btn_A.Click += new System.EventHandler(this.btn_A_Click);
            // 
            // lbl_jawab5
            // 
            this.lbl_jawab5.AutoSize = true;
            this.lbl_jawab5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_jawab5.Location = new System.Drawing.Point(709, 122);
            this.lbl_jawab5.Name = "lbl_jawab5";
            this.lbl_jawab5.Size = new System.Drawing.Size(46, 51);
            this.lbl_jawab5.TabIndex = 79;
            this.lbl_jawab5.Text = "_";
            this.lbl_jawab5.Visible = false;
            // 
            // lbl_jawab4
            // 
            this.lbl_jawab4.AutoSize = true;
            this.lbl_jawab4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_jawab4.Location = new System.Drawing.Point(619, 122);
            this.lbl_jawab4.Name = "lbl_jawab4";
            this.lbl_jawab4.Size = new System.Drawing.Size(46, 51);
            this.lbl_jawab4.TabIndex = 78;
            this.lbl_jawab4.Text = "_";
            this.lbl_jawab4.Visible = false;
            // 
            // lbl_jawab3
            // 
            this.lbl_jawab3.AutoSize = true;
            this.lbl_jawab3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_jawab3.Location = new System.Drawing.Point(523, 122);
            this.lbl_jawab3.Name = "lbl_jawab3";
            this.lbl_jawab3.Size = new System.Drawing.Size(46, 51);
            this.lbl_jawab3.TabIndex = 77;
            this.lbl_jawab3.Text = "_";
            this.lbl_jawab3.Visible = false;
            // 
            // lbl_jawab2
            // 
            this.lbl_jawab2.AutoSize = true;
            this.lbl_jawab2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_jawab2.Location = new System.Drawing.Point(443, 122);
            this.lbl_jawab2.Name = "lbl_jawab2";
            this.lbl_jawab2.Size = new System.Drawing.Size(46, 51);
            this.lbl_jawab2.TabIndex = 76;
            this.lbl_jawab2.Text = "_";
            this.lbl_jawab2.Visible = false;
            // 
            // lbl_jawab1
            // 
            this.lbl_jawab1.AutoSize = true;
            this.lbl_jawab1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_jawab1.Location = new System.Drawing.Point(360, 122);
            this.lbl_jawab1.Name = "lbl_jawab1";
            this.lbl_jawab1.Size = new System.Drawing.Size(46, 51);
            this.lbl_jawab1.TabIndex = 75;
            this.lbl_jawab1.Text = "_";
            this.lbl_jawab1.Visible = false;
            // 
            // lbl_jawaban
            // 
            this.lbl_jawaban.AutoSize = true;
            this.lbl_jawaban.Location = new System.Drawing.Point(914, 54);
            this.lbl_jawaban.Name = "lbl_jawaban";
            this.lbl_jawaban.Size = new System.Drawing.Size(67, 25);
            this.lbl_jawaban.TabIndex = 109;
            this.lbl_jawaban.Text = "KATA";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1632, 854);
            this.Controls.Add(this.pnl2_tampilan);
            this.Controls.Add(this.pnl_tampilan);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnl_tampilan.ResumeLayout(false);
            this.pnl_tampilan.PerformLayout();
            this.pnl2_tampilan.ResumeLayout(false);
            this.pnl2_tampilan.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox bx_kata_1;
        private System.Windows.Forms.TextBox bx_kata_2;
        private System.Windows.Forms.TextBox bx_kata_3;
        private System.Windows.Forms.TextBox bx_kata_4;
        private System.Windows.Forms.TextBox bx_kata_5;
        private System.Windows.Forms.Label lbl_1;
        private System.Windows.Forms.Label lbl_2;
        private System.Windows.Forms.Label lbl_4;
        private System.Windows.Forms.Label lbl_5;
        private System.Windows.Forms.Label lbl_3;
        private System.Windows.Forms.Button btn_play;
        private System.Windows.Forms.Panel pnl_tampilan;
        private System.Windows.Forms.Panel pnl2_tampilan;
        private System.Windows.Forms.Button btn_L;
        private System.Windows.Forms.Button btn_O;
        private System.Windows.Forms.Button btn_K;
        private System.Windows.Forms.Button btn_i;
        private System.Windows.Forms.Button btn_M;
        private System.Windows.Forms.Button btn_J;
        private System.Windows.Forms.Button btn_U;
        private System.Windows.Forms.Button btn_N;
        private System.Windows.Forms.Button btn_H;
        private System.Windows.Forms.Button btn_Y;
        private System.Windows.Forms.Button btn_B;
        private System.Windows.Forms.Button btn_G;
        private System.Windows.Forms.Button btn_T;
        private System.Windows.Forms.Button btn_V;
        private System.Windows.Forms.Button btn_F;
        private System.Windows.Forms.Button btn_R;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Button btn_D;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_X;
        private System.Windows.Forms.Button btn_S;
        private System.Windows.Forms.Button btn_W;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Label lbl_jawab5;
        private System.Windows.Forms.Label lbl_jawab4;
        private System.Windows.Forms.Label lbl_jawab3;
        private System.Windows.Forms.Label lbl_jawab2;
        private System.Windows.Forms.Label lbl_jawab1;
        private System.Windows.Forms.Button btn_Z;
        private System.Windows.Forms.Button btn_Q;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Label lbl_jawaban;
    }
}

