﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_play_Click(object sender, EventArgs e)
        {
            string angka = "1234567890";
            foreach (char a in angka)
            {
                if (bx_kata_1.Text.Contains(a) || bx_kata_2.Text.Contains(a) || bx_kata_3.Text.Contains(a) || bx_kata_4.Text.Contains(a) || bx_kata_5.Text.Contains(a))
                {
                    MessageBox.Show("terdapat angka!");
                    return;
                }
            }
            if (bx_kata_1.Text == "" || bx_kata_2.Text == "" || bx_kata_3.Text == "" || bx_kata_4.Text == "" || bx_kata_5.Text == "")
            {
                MessageBox.Show("1 box kosong!");
                return;
            }
            if (bx_kata_1.Text.Length != 5 || bx_kata_2.Text.Length != 5 || bx_kata_3.Text.Length != 5 || bx_kata_4.Text.Length != 5 || bx_kata_5.Text.Length != 5)
            {
                MessageBox.Show("kata kurang dari 5 huruf");
                return;
            }
            if (bx_kata_1.Text == bx_kata_2.Text || bx_kata_1.Text == bx_kata_3.Text || bx_kata_1.Text == bx_kata_4.Text || bx_kata_1.Text == bx_kata_5.Text || bx_kata_2.Text == bx_kata_1.Text || bx_kata_2.Text == bx_kata_3.Text || bx_kata_2.Text == bx_kata_4.Text || bx_kata_2.Text == bx_kata_5.Text || bx_kata_3.Text == bx_kata_1.Text || bx_kata_3.Text == bx_kata_2.Text || bx_kata_3.Text == bx_kata_4.Text || bx_kata_3.Text == bx_kata_5.Text || bx_kata_4.Text == bx_kata_1.Text || bx_kata_4.Text == bx_kata_2.Text || bx_kata_4.Text == bx_kata_3.Text || bx_kata_4.Text == bx_kata_5.Text || bx_kata_5.Text == bx_kata_1.Text || bx_kata_5.Text == bx_kata_2.Text || bx_kata_5.Text == bx_kata_3.Text || bx_kata_5.Text == bx_kata_4.Text)
            {
                MessageBox.Show("kata sama!");
                return;
            }
            pnl_tampilan.Top = 1500;
            pnl2_tampilan.Visible = true;
            string[] jawaban = new string[5];
            jawaban[0] = bx_kata_1.Text;
            jawaban[1] = bx_kata_2.Text;
            jawaban[2] = bx_kata_3.Text;
            jawaban[3] = bx_kata_4.Text;
            jawaban[4] = bx_kata_5.Text;
            Random Acak = new Random();
            int pilih = Acak.Next(0, 5);
            string kata = jawaban[pilih];
            kata = kata.ToUpper();
            string[] pilihkata = new string[5];
            int count = 0;
            foreach (char x in kata)
            {
                pilihkata[count] = x.ToString();
                count++;
            }
            lbl_jawab1.Text = pilihkata[0];
            lbl_jawab2.Text = pilihkata[1];
            lbl_jawab3.Text = pilihkata[2];
            lbl_jawab4.Text = pilihkata[3];
            lbl_jawab5.Text = pilihkata[4];
            lbl_jawaban.Text = kata;
            
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            pnl_tampilan.Top = 60;
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("Q"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("Q"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("Q"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("Q"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("Q"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("A"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("A"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("A"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("A"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("A"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("Z"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("Z"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("Z"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("Z"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("Z"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("W"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("W"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("W"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("W"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("W"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("S"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("S"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("S"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("S"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("S"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("X"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("X"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("X"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("X"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("X"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("E"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("E"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("E"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("E"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("E"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("D"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("D"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("D"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("D"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("D"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("C"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("C"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("C"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("C"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("C"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("R"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("R"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("R"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("R"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("R"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("F"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("F"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("F"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("F"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("F"))
            {
                lbl_jawab5.Visible = true;
            }
        }
        private void btn_V_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("V"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("V"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("V"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("V"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("V"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("T"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("T"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("T"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("T"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("T"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("G"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("G"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("G"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("G"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("G"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("B"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("B"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("B"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("B"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("S"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("Y"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("Y"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("Y"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("Y"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("Y"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("H"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("H"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("H"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("H"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("H"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("N"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("N"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("N"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("N"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("N"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("U"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("U"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("U"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("U"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("U"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("J"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("J"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("J"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("J"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("J"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("M"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("M"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("M"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("M"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("M"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_i_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("I"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("I"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("I"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("I"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("I"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("K"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("K"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("K"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("K"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("K"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("O"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("O"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("O"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("O"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("O"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("L"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("L"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("L"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("L"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("L"))
            {
                lbl_jawab5.Visible = true;
            }
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            if (lbl_jawab1.Visible == true && lbl_jawab2.Visible == true && lbl_jawab3.Visible == true && lbl_jawab4.Visible == true && lbl_jawaban.Visible == true)
            {
                MessageBox.Show("SUDAH SELESAI");
            }
            if (lbl_jawab1.Text.Contains("P"))
            {
                lbl_jawab1.Visible = true;
            }
            if (lbl_jawab2.Text.Contains("P"))
            {
                lbl_jawab2.Visible = true;
            }
            if (lbl_jawab3.Text.Contains("P"))
            {
                lbl_jawab3.Visible = true;
            }
            if (lbl_jawab4.Text.Contains("P"))
            {
                lbl_jawab4.Visible = true;
            }
            if (lbl_jawab5.Text.Contains("P"))
            {
                lbl_jawab5.Visible = true;
            }
        }
    }
}