﻿namespace WindowsFormsApp13
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_teamHome = new System.Windows.Forms.Label();
            this.cb_teamHome = new System.Windows.Forms.ComboBox();
            this.dgv_match = new System.Windows.Forms.DataGridView();
            this.cb_teamAway = new System.Windows.Forms.ComboBox();
            this.lbl_teamAway = new System.Windows.Forms.Label();
            this.lbl_matchID = new System.Windows.Forms.Label();
            this.tb_matchID = new System.Windows.Forms.TextBox();
            this.lbl_date = new System.Windows.Forms.Label();
            this.dtp_match = new System.Windows.Forms.DateTimePicker();
            this.tb_menit = new System.Windows.Forms.TextBox();
            this.lbl_minute = new System.Windows.Forms.Label();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.lbl_team = new System.Windows.Forms.Label();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.lbl_player = new System.Windows.Forms.Label();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.lbl_type = new System.Windows.Forms.Label();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_match)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_teamHome
            // 
            this.lbl_teamHome.AutoSize = true;
            this.lbl_teamHome.Location = new System.Drawing.Point(33, 165);
            this.lbl_teamHome.Name = "lbl_teamHome";
            this.lbl_teamHome.Size = new System.Drawing.Size(128, 25);
            this.lbl_teamHome.TabIndex = 0;
            this.lbl_teamHome.Text = "Team Home";
            // 
            // cb_teamHome
            // 
            this.cb_teamHome.FormattingEnabled = true;
            this.cb_teamHome.Location = new System.Drawing.Point(177, 157);
            this.cb_teamHome.Name = "cb_teamHome";
            this.cb_teamHome.Size = new System.Drawing.Size(278, 33);
            this.cb_teamHome.TabIndex = 1;
            this.cb_teamHome.SelectedIndexChanged += new System.EventHandler(this.cb_teamHome_SelectedIndexChanged);
            // 
            // dgv_match
            // 
            this.dgv_match.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_match.Location = new System.Drawing.Point(37, 298);
            this.dgv_match.Name = "dgv_match";
            this.dgv_match.RowHeadersWidth = 82;
            this.dgv_match.RowTemplate.Height = 33;
            this.dgv_match.Size = new System.Drawing.Size(1025, 428);
            this.dgv_match.TabIndex = 9;
            // 
            // cb_teamAway
            // 
            this.cb_teamAway.FormattingEnabled = true;
            this.cb_teamAway.Location = new System.Drawing.Point(719, 157);
            this.cb_teamAway.Name = "cb_teamAway";
            this.cb_teamAway.Size = new System.Drawing.Size(363, 33);
            this.cb_teamAway.TabIndex = 11;
            this.cb_teamAway.SelectedIndexChanged += new System.EventHandler(this.cb_teamAway_SelectedIndexChanged);
            // 
            // lbl_teamAway
            // 
            this.lbl_teamAway.AutoSize = true;
            this.lbl_teamAway.Location = new System.Drawing.Point(575, 165);
            this.lbl_teamAway.Name = "lbl_teamAway";
            this.lbl_teamAway.Size = new System.Drawing.Size(124, 25);
            this.lbl_teamAway.TabIndex = 10;
            this.lbl_teamAway.Text = "Team Away";
            // 
            // lbl_matchID
            // 
            this.lbl_matchID.AutoSize = true;
            this.lbl_matchID.Location = new System.Drawing.Point(33, 82);
            this.lbl_matchID.Name = "lbl_matchID";
            this.lbl_matchID.Size = new System.Drawing.Size(97, 25);
            this.lbl_matchID.TabIndex = 12;
            this.lbl_matchID.Text = "Match ID";
            // 
            // tb_matchID
            // 
            this.tb_matchID.Enabled = false;
            this.tb_matchID.Location = new System.Drawing.Point(177, 75);
            this.tb_matchID.Name = "tb_matchID";
            this.tb_matchID.Size = new System.Drawing.Size(278, 31);
            this.tb_matchID.TabIndex = 13;
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Location = new System.Drawing.Point(575, 82);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(122, 25);
            this.lbl_date.TabIndex = 14;
            this.lbl_date.Text = "Match Date";
            // 
            // dtp_match
            // 
            this.dtp_match.Location = new System.Drawing.Point(719, 74);
            this.dtp_match.Name = "dtp_match";
            this.dtp_match.Size = new System.Drawing.Size(363, 31);
            this.dtp_match.TabIndex = 15;
            // 
            // tb_menit
            // 
            this.tb_menit.Location = new System.Drawing.Point(1244, 368);
            this.tb_menit.Name = "tb_menit";
            this.tb_menit.Size = new System.Drawing.Size(278, 31);
            this.tb_menit.TabIndex = 19;
            // 
            // lbl_minute
            // 
            this.lbl_minute.AutoSize = true;
            this.lbl_minute.Location = new System.Drawing.Point(1100, 375);
            this.lbl_minute.Name = "lbl_minute";
            this.lbl_minute.Size = new System.Drawing.Size(77, 25);
            this.lbl_minute.TabIndex = 18;
            this.lbl_minute.Text = "Minute";
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(1244, 450);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(278, 33);
            this.cb_team.TabIndex = 17;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // lbl_team
            // 
            this.lbl_team.AutoSize = true;
            this.lbl_team.Location = new System.Drawing.Point(1100, 458);
            this.lbl_team.Name = "lbl_team";
            this.lbl_team.Size = new System.Drawing.Size(66, 25);
            this.lbl_team.TabIndex = 16;
            this.lbl_team.Text = "Team";
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(1244, 534);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(278, 33);
            this.cb_player.TabIndex = 21;
            // 
            // lbl_player
            // 
            this.lbl_player.AutoSize = true;
            this.lbl_player.Location = new System.Drawing.Point(1100, 542);
            this.lbl_player.Name = "lbl_player";
            this.lbl_player.Size = new System.Drawing.Size(73, 25);
            this.lbl_player.TabIndex = 20;
            this.lbl_player.Text = "Player";
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Items.AddRange(new object[] {
            "GO",
            "GP",
            "GW",
            "CR",
            "CY",
            "PM"});
            this.cb_type.Location = new System.Drawing.Point(1244, 611);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(278, 33);
            this.cb_type.TabIndex = 23;
            // 
            // lbl_type
            // 
            this.lbl_type.AutoSize = true;
            this.lbl_type.Location = new System.Drawing.Point(1100, 619);
            this.lbl_type.Name = "lbl_type";
            this.lbl_type.Size = new System.Drawing.Size(60, 25);
            this.lbl_type.TabIndex = 22;
            this.lbl_type.Text = "Type";
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(1127, 702);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(150, 63);
            this.btn_add.TabIndex = 24;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(433, 774);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(150, 63);
            this.btn_insert.TabIndex = 25;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1357, 702);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(150, 63);
            this.btn_delete.TabIndex = 26;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1996, 1161);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.lbl_type);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.lbl_player);
            this.Controls.Add(this.tb_menit);
            this.Controls.Add(this.lbl_minute);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.lbl_team);
            this.Controls.Add(this.dtp_match);
            this.Controls.Add(this.lbl_date);
            this.Controls.Add(this.tb_matchID);
            this.Controls.Add(this.lbl_matchID);
            this.Controls.Add(this.cb_teamAway);
            this.Controls.Add(this.lbl_teamAway);
            this.Controls.Add(this.dgv_match);
            this.Controls.Add(this.cb_teamHome);
            this.Controls.Add(this.lbl_teamHome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_match)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_teamHome;
        private System.Windows.Forms.ComboBox cb_teamHome;
        private System.Windows.Forms.DataGridView dgv_match;
        private System.Windows.Forms.ComboBox cb_teamAway;
        private System.Windows.Forms.Label lbl_teamAway;
        private System.Windows.Forms.Label lbl_matchID;
        private System.Windows.Forms.TextBox tb_matchID;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.DateTimePicker dtp_match;
        private System.Windows.Forms.TextBox tb_menit;
        private System.Windows.Forms.Label lbl_minute;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.Label lbl_team;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.Label lbl_player;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.Label lbl_type;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.Button btn_delete;
    }
}

