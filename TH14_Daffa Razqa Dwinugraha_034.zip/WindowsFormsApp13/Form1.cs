﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp13
{
    public partial class Form1 : Form
    {
        MySqlConnection conn;
        MySqlCommand cmd;
        MySqlDataAdapter adptr;
        string query;
        DataTable teamHome = new DataTable();
        DataTable teamAway = new DataTable();
        DataTable dt = new DataTable();
        DataTable type = new DataTable();
        

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            conn = new MySqlConnection("server = localhost; uid = root; pwd = Betulbetulbetul3; database = premier_league");
            conn.Open();
            conn.Close();
            query = "select team_name, team_id from team";
            cmd = new MySqlCommand(query,conn);
            adptr = new MySqlDataAdapter(cmd);
            adptr.Fill(teamHome);
            cb_teamHome.DataSource = teamHome;
            cb_teamHome.DisplayMember = "team_name";
            cb_teamHome.ValueMember = "team_id";
            cb_teamHome.Text = "";

            query = "select team_name, team_id from team";
            cmd = new MySqlCommand(query, conn);
            adptr = new MySqlDataAdapter(cmd);
            adptr.Fill(teamAway);
            cb_teamAway.DataSource = teamAway;
            cb_teamAway.DisplayMember = "team_name";
            cb_teamAway.ValueMember = "team_id";
            cb_teamAway.Text = "";

            cb_team.Items.Add(cb_teamHome.Text);
            dt.Columns.Add("minute");
            dt.Columns.Add("team");
            dt.Columns.Add("player");
            dt.Columns.Add("type");
            
            dgv_match.DataSource = dt;

        }

        private void cb_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamHome.Text == cb_teamAway.Text)
            {
                MessageBox.Show("Tim tidak boleh sama");
            }
            if (cb_teamHome != null & cb_teamAway != null)
            {
                cb_team.Items.Clear();
                cb_team.Items.Add(cb_teamHome.Text);
                cb_team.Items.Add(cb_teamAway.Text);
            }
            DataTable ID = new DataTable();
            query = $"select match_id from `match` where team_home = '{cb_teamHome.SelectedValue}' && team_away = '{cb_teamAway.SelectedValue}'";
            cmd = new MySqlCommand(query,conn);
            adptr = new MySqlDataAdapter(cmd);
            adptr.Fill(ID);
            if (ID.Rows.Count != 0)
            {
                tb_matchID.Clear();
                tb_matchID.Text = ID.Rows[0][0].ToString();
            }
        }

        private void cb_teamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamAway.Text == cb_teamHome.Text)
            {
                MessageBox.Show("Tim tidak boleh sama");
            }
            if (cb_teamHome != null & cb_teamAway != null)
            {
                cb_team.Items.Clear();
                cb_team.Items.Add(cb_teamHome.Text);
                cb_team.Items.Add(cb_teamAway.Text);
            }
            DataTable ID = new DataTable();
            query = $"select match_id from `match` where team_home = '{cb_teamHome.SelectedValue}' && team_away = '{cb_teamAway.SelectedValue}'";
            cmd = new MySqlCommand(query, conn);
            adptr = new MySqlDataAdapter(cmd);
            adptr.Fill(ID);
            if (ID.Rows.Count != 0)
            {
                tb_matchID.Clear();
                tb_matchID.Text = ID.Rows[0][0].ToString();
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable player = new DataTable();
            string query = "select player_name from player left join team on team.team_name = '" + cb_team.Text + "' where player.team_id = team.team_id AND status = 1 group by player_name";
            cmd = new MySqlCommand(query, conn);
            adptr = new MySqlDataAdapter(cmd);
            adptr.Fill(player);
            cb_player.DataSource = player;
            cb_player.DisplayMember = "player";
            cb_player.ValueMember = "player_name";
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (tb_menit.Text == "" && cb_team.Text == "" && cb_player.Text == "" && cb_type.Text == "")
            {
                MessageBox.Show("Ada kosong");
            }
            else
            {
                dt.Rows.Add(tb_menit.Text, cb_team.Text, cb_player.Text, cb_type.Text);
                tb_menit.Text = "";
                cb_team.SelectedItem = null;
                cb_player.SelectedItem = null;
                cb_type.SelectedItem = null;
            }
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow dr in dgv_match.SelectedRows)
            {
                dgv_match.Rows.RemoveAt(dr.Index);
            }
        }
    }
}
