﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        List<string>Uname = new List<string>();
        List<string>Pass = new List<string>();
        List<int> Saldo = new List<int>();
        int akun;
        public Form1()
        {
            InitializeComponent();
        }
        private void btn_register_Click(object sender, EventArgs e)
        {
            pnl_menu.Visible = false;
            pnl_register.Visible = true;
            tb_Uname.Clear();
            tb_Pass.Clear();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {;
            int count = 0;
            bool Password = false;
            akun = 0;
            foreach (string x in Uname)
            {
                if (tb_Uname.Text == x)
                {
                    akun = count;
                    Password = true;
                }
                count++;
            }
            if (Password == false)
            {
                MessageBox.Show("akun tidak ditemukan!");
                return;
            }
            else
            {
                if (Pass[akun] != tb_Pass.Text)
                {
                    Password = false;
                    MessageBox.Show("password salah!");
                }
            }
            if (Password == true)
            {
                MessageBox.Show("Selamat datang" + " " + tb_Uname.Text);
                pnl_menu.Visible = false;
                pnl_register.Visible = false;
                pnl_bank.Visible = true;
                string saldo = Saldo[akun].ToString("N0");
                lbl_amount.Text = "Rp. " + saldo + ",00";
                tb_Uname.Clear();
                tb_Pass.Clear();
            }
        }

        private void btn_register2_Click(object sender, EventArgs e)
        {
            if (Uname.Contains(tb_Uname2.Text))
            {
                MessageBox.Show("akun sudah ada! Input ulang");
                tb_Uname2.Clear();
                tb_pass2.Clear();
                return;
            }
            else
            {
                Uname.Add(tb_Uname2.Text);
                Pass.Add(tb_pass2.Text);
                Saldo.Add(0);
                pnl_register.Visible = false;
                pnl_menu.Visible = true;
                tb_Uname2.Clear();
                tb_pass2.Clear();
                MessageBox.Show("akun berhasil terdaftar");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            pnl_bank.Visible = false;
            pnl_deposit.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pnl_menu.Top = 60;
            pnl_register.Top = 60;
            pnl_bank.Top = 60;
            pnl_deposit.Top = 60;
            pnl_tarik.Top = 60;
            BackColor = Color.AliceBlue;
        }

        private void btn_logOut_Click(object sender, EventArgs e)
        {
            pnl_tarik.Visible = false;
            pnl_bank.Visible = false;
            pnl_register.Visible = false;
            pnl_deposit.Visible = false;
            pnl_menu.Visible = true;
        }

        private void btn_setor_Click(object sender, EventArgs e)
        {
            pnl_deposit.Visible = false;
            pnl_bank.Visible = true;
            string deposits = tb_deposit.Text.Replace(".", "");
            if (int.TryParse(deposits, out int number))
            {
                int deposit = Convert.ToInt32(deposits);
                if (deposit <= 0)
                {
                    MessageBox.Show("uang ga mencukupi");
                }
                else
                {
                    Saldo[akun] = Saldo[akun] + deposit;
                    MessageBox.Show("berhasil setor uang Rp." + deposit.ToString("N0") + ",00");
                    tb_deposit.Clear();
                    lbl_amount.Text = "Rp." + Saldo[akun].ToString("N0") + ",00";
                }
            }
            else
            {
                MessageBox.Show("Input Error");
            }
        }

        private void btn_keluar_Click(object sender, EventArgs e)
        {
            pnl_tarik.Visible = false;
            pnl_bank.Visible = false;
            pnl_register.Visible = false;
            pnl_deposit.Visible = false;
            pnl_menu.Visible = true;
        }

        private void btn_out_Click(object sender, EventArgs e)
        {
            pnl_tarik.Visible = false;
            pnl_bank.Visible = false;
            pnl_register.Visible = false;
            pnl_deposit.Visible = false;
            pnl_menu.Visible = true;
        }

        private void btn_tarik_Click(object sender, EventArgs e)
        {
            pnl_tarik.Visible = false;
            pnl_bank.Visible = true;
            string tbwithdraw = tb_tarik.Text.Replace(".", "");
            if (int.TryParse(tbwithdraw, out int number))
            {
                int withdraw = Convert.ToInt32(tbwithdraw);
                if (Saldo[akun] >= withdraw)
                {
                    Saldo[akun] = Saldo[akun] - withdraw;
                    MessageBox.Show("sukses tarik Rp." + withdraw.ToString("N0") + ",00");
                    tb_tarik.Clear();
                    lbl_amount.Text = "Rp." + Saldo[akun].ToString("N0") + ",00";
                }
                else
                {
                    MessageBox.Show("Saldo kurang dari permintaan");
                }
            }
            else
            {
                MessageBox.Show("Input Error");
            }
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            pnl_tarik.Visible = true;
            pnl_bank.Visible = false;
        }
    }
}
