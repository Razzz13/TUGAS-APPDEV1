﻿namespace WindowsFormsApp6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_menu = new System.Windows.Forms.Panel();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_register = new System.Windows.Forms.Button();
            this.tb_Pass = new System.Windows.Forms.TextBox();
            this.lbl_pass = new System.Windows.Forms.Label();
            this.tb_Uname = new System.Windows.Forms.TextBox();
            this.lbl_Uname = new System.Windows.Forms.Label();
            this.lbl_bank = new System.Windows.Forms.Label();
            this.pnl_register = new System.Windows.Forms.Panel();
            this.btn_register2 = new System.Windows.Forms.Button();
            this.tb_pass2 = new System.Windows.Forms.TextBox();
            this.lbl_password2 = new System.Windows.Forms.Label();
            this.tb_Uname2 = new System.Windows.Forms.TextBox();
            this.lbl_Uname2 = new System.Windows.Forms.Label();
            this.lbl_bank2 = new System.Windows.Forms.Label();
            this.pnl_bank = new System.Windows.Forms.Panel();
            this.lbl_amount = new System.Windows.Forms.Label();
            this.btn_logOut = new System.Windows.Forms.Button();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.lbl_bank3 = new System.Windows.Forms.Label();
            this.pnl_deposit = new System.Windows.Forms.Panel();
            this.btn_setor = new System.Windows.Forms.Button();
            this.btn_keluar = new System.Windows.Forms.Button();
            this.tb_deposit = new System.Windows.Forms.TextBox();
            this.lbl_inptDeposit = new System.Windows.Forms.Label();
            this.lbl_bank4 = new System.Windows.Forms.Label();
            this.pnl_tarik = new System.Windows.Forms.Panel();
            this.lbl_tarik = new System.Windows.Forms.Label();
            this.tb_tarik = new System.Windows.Forms.TextBox();
            this.btn_out = new System.Windows.Forms.Button();
            this.btn_tarik = new System.Windows.Forms.Button();
            this.lbl_bank5 = new System.Windows.Forms.Label();
            this.pnl_menu.SuspendLayout();
            this.pnl_register.SuspendLayout();
            this.pnl_bank.SuspendLayout();
            this.pnl_deposit.SuspendLayout();
            this.pnl_tarik.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_menu
            // 
            this.pnl_menu.Controls.Add(this.btn_login);
            this.pnl_menu.Controls.Add(this.btn_register);
            this.pnl_menu.Controls.Add(this.tb_Pass);
            this.pnl_menu.Controls.Add(this.lbl_pass);
            this.pnl_menu.Controls.Add(this.tb_Uname);
            this.pnl_menu.Controls.Add(this.lbl_Uname);
            this.pnl_menu.Controls.Add(this.lbl_bank);
            this.pnl_menu.Location = new System.Drawing.Point(12, 22);
            this.pnl_menu.Name = "pnl_menu";
            this.pnl_menu.Size = new System.Drawing.Size(480, 441);
            this.pnl_menu.TabIndex = 0;
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(169, 388);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(130, 50);
            this.btn_login.TabIndex = 6;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_register
            // 
            this.btn_register.Location = new System.Drawing.Point(169, 304);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(130, 56);
            this.btn_register.TabIndex = 5;
            this.btn_register.Text = "Register";
            this.btn_register.UseVisualStyleBackColor = true;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // tb_Pass
            // 
            this.tb_Pass.Location = new System.Drawing.Point(143, 214);
            this.tb_Pass.Name = "tb_Pass";
            this.tb_Pass.Size = new System.Drawing.Size(234, 31);
            this.tb_Pass.TabIndex = 4;
            // 
            // lbl_pass
            // 
            this.lbl_pass.AutoSize = true;
            this.lbl_pass.Location = new System.Drawing.Point(24, 214);
            this.lbl_pass.Name = "lbl_pass";
            this.lbl_pass.Size = new System.Drawing.Size(106, 25);
            this.lbl_pass.TabIndex = 3;
            this.lbl_pass.Text = "Password";
            // 
            // tb_Uname
            // 
            this.tb_Uname.Location = new System.Drawing.Point(143, 162);
            this.tb_Uname.Name = "tb_Uname";
            this.tb_Uname.Size = new System.Drawing.Size(234, 31);
            this.tb_Uname.TabIndex = 2;
            // 
            // lbl_Uname
            // 
            this.lbl_Uname.AutoSize = true;
            this.lbl_Uname.Location = new System.Drawing.Point(19, 162);
            this.lbl_Uname.Name = "lbl_Uname";
            this.lbl_Uname.Size = new System.Drawing.Size(110, 25);
            this.lbl_Uname.TabIndex = 1;
            this.lbl_Uname.Text = "Username";
            // 
            // lbl_bank
            // 
            this.lbl_bank.AutoSize = true;
            this.lbl_bank.Font = new System.Drawing.Font("Microsoft YaHei", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bank.Location = new System.Drawing.Point(135, 35);
            this.lbl_bank.Name = "lbl_bank";
            this.lbl_bank.Size = new System.Drawing.Size(186, 48);
            this.lbl_bank.TabIndex = 0;
            this.lbl_bank.Text = "UC BANK";
            // 
            // pnl_register
            // 
            this.pnl_register.Controls.Add(this.btn_register2);
            this.pnl_register.Controls.Add(this.tb_pass2);
            this.pnl_register.Controls.Add(this.lbl_password2);
            this.pnl_register.Controls.Add(this.tb_Uname2);
            this.pnl_register.Controls.Add(this.lbl_Uname2);
            this.pnl_register.Controls.Add(this.lbl_bank2);
            this.pnl_register.Location = new System.Drawing.Point(498, 22);
            this.pnl_register.Name = "pnl_register";
            this.pnl_register.Size = new System.Drawing.Size(480, 441);
            this.pnl_register.TabIndex = 1;
            this.pnl_register.Visible = false;
            // 
            // btn_register2
            // 
            this.btn_register2.Location = new System.Drawing.Point(171, 349);
            this.btn_register2.Name = "btn_register2";
            this.btn_register2.Size = new System.Drawing.Size(130, 56);
            this.btn_register2.TabIndex = 5;
            this.btn_register2.Text = "Register";
            this.btn_register2.UseVisualStyleBackColor = true;
            this.btn_register2.Click += new System.EventHandler(this.btn_register2_Click);
            // 
            // tb_pass2
            // 
            this.tb_pass2.Location = new System.Drawing.Point(143, 214);
            this.tb_pass2.Name = "tb_pass2";
            this.tb_pass2.Size = new System.Drawing.Size(234, 31);
            this.tb_pass2.TabIndex = 4;
            // 
            // lbl_password2
            // 
            this.lbl_password2.AutoSize = true;
            this.lbl_password2.Location = new System.Drawing.Point(24, 214);
            this.lbl_password2.Name = "lbl_password2";
            this.lbl_password2.Size = new System.Drawing.Size(106, 25);
            this.lbl_password2.TabIndex = 3;
            this.lbl_password2.Text = "Password";
            // 
            // tb_Uname2
            // 
            this.tb_Uname2.Location = new System.Drawing.Point(143, 162);
            this.tb_Uname2.Name = "tb_Uname2";
            this.tb_Uname2.Size = new System.Drawing.Size(234, 31);
            this.tb_Uname2.TabIndex = 2;
            // 
            // lbl_Uname2
            // 
            this.lbl_Uname2.AutoSize = true;
            this.lbl_Uname2.Location = new System.Drawing.Point(19, 162);
            this.lbl_Uname2.Name = "lbl_Uname2";
            this.lbl_Uname2.Size = new System.Drawing.Size(110, 25);
            this.lbl_Uname2.TabIndex = 1;
            this.lbl_Uname2.Text = "Username";
            // 
            // lbl_bank2
            // 
            this.lbl_bank2.AutoSize = true;
            this.lbl_bank2.Font = new System.Drawing.Font("Microsoft YaHei", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bank2.Location = new System.Drawing.Point(135, 35);
            this.lbl_bank2.Name = "lbl_bank2";
            this.lbl_bank2.Size = new System.Drawing.Size(186, 48);
            this.lbl_bank2.TabIndex = 0;
            this.lbl_bank2.Text = "UC BANK";
            // 
            // pnl_bank
            // 
            this.pnl_bank.Controls.Add(this.lbl_amount);
            this.pnl_bank.Controls.Add(this.btn_logOut);
            this.pnl_bank.Controls.Add(this.btn_deposit);
            this.pnl_bank.Controls.Add(this.btn_withdraw);
            this.pnl_bank.Controls.Add(this.lbl_balance);
            this.pnl_bank.Controls.Add(this.lbl_bank3);
            this.pnl_bank.Location = new System.Drawing.Point(12, 488);
            this.pnl_bank.Name = "pnl_bank";
            this.pnl_bank.Size = new System.Drawing.Size(480, 441);
            this.pnl_bank.TabIndex = 3;
            this.pnl_bank.Visible = false;
            // 
            // lbl_amount
            // 
            this.lbl_amount.AutoSize = true;
            this.lbl_amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_amount.Location = new System.Drawing.Point(183, 202);
            this.lbl_amount.Name = "lbl_amount";
            this.lbl_amount.Size = new System.Drawing.Size(84, 37);
            this.lbl_amount.TabIndex = 8;
            this.lbl_amount.Text = "Rp.0";
            // 
            // btn_logOut
            // 
            this.btn_logOut.Location = new System.Drawing.Point(344, 93);
            this.btn_logOut.Name = "btn_logOut";
            this.btn_logOut.Size = new System.Drawing.Size(102, 47);
            this.btn_logOut.TabIndex = 7;
            this.btn_logOut.Text = "Log Out";
            this.btn_logOut.UseVisualStyleBackColor = true;
            this.btn_logOut.Click += new System.EventHandler(this.btn_logOut_Click);
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(171, 287);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(130, 56);
            this.btn_deposit.TabIndex = 6;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.Location = new System.Drawing.Point(171, 349);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(130, 56);
            this.btn_withdraw.TabIndex = 5;
            this.btn_withdraw.Text = "Withdraw";
            this.btn_withdraw.UseVisualStyleBackColor = true;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // lbl_balance
            // 
            this.lbl_balance.AutoSize = true;
            this.lbl_balance.Location = new System.Drawing.Point(29, 203);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(90, 25);
            this.lbl_balance.TabIndex = 1;
            this.lbl_balance.Text = "Balance";
            // 
            // lbl_bank3
            // 
            this.lbl_bank3.AutoSize = true;
            this.lbl_bank3.Font = new System.Drawing.Font("Microsoft YaHei", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bank3.Location = new System.Drawing.Point(135, 35);
            this.lbl_bank3.Name = "lbl_bank3";
            this.lbl_bank3.Size = new System.Drawing.Size(186, 48);
            this.lbl_bank3.TabIndex = 0;
            this.lbl_bank3.Text = "UC BANK";
            // 
            // pnl_deposit
            // 
            this.pnl_deposit.Controls.Add(this.btn_setor);
            this.pnl_deposit.Controls.Add(this.btn_keluar);
            this.pnl_deposit.Controls.Add(this.tb_deposit);
            this.pnl_deposit.Controls.Add(this.lbl_inptDeposit);
            this.pnl_deposit.Controls.Add(this.lbl_bank4);
            this.pnl_deposit.Location = new System.Drawing.Point(498, 488);
            this.pnl_deposit.Name = "pnl_deposit";
            this.pnl_deposit.Size = new System.Drawing.Size(480, 441);
            this.pnl_deposit.TabIndex = 4;
            this.pnl_deposit.Visible = false;
            // 
            // btn_setor
            // 
            this.btn_setor.Location = new System.Drawing.Point(171, 317);
            this.btn_setor.Name = "btn_setor";
            this.btn_setor.Size = new System.Drawing.Size(130, 56);
            this.btn_setor.TabIndex = 9;
            this.btn_setor.Text = "Deposit";
            this.btn_setor.UseVisualStyleBackColor = true;
            this.btn_setor.Click += new System.EventHandler(this.btn_setor_Click);
            // 
            // btn_keluar
            // 
            this.btn_keluar.Location = new System.Drawing.Point(333, 93);
            this.btn_keluar.Name = "btn_keluar";
            this.btn_keluar.Size = new System.Drawing.Size(102, 47);
            this.btn_keluar.TabIndex = 8;
            this.btn_keluar.Text = "Log Out";
            this.btn_keluar.UseVisualStyleBackColor = true;
            this.btn_keluar.Click += new System.EventHandler(this.btn_keluar_Click);
            // 
            // tb_deposit
            // 
            this.tb_deposit.Location = new System.Drawing.Point(166, 208);
            this.tb_deposit.Name = "tb_deposit";
            this.tb_deposit.Size = new System.Drawing.Size(234, 31);
            this.tb_deposit.TabIndex = 4;
            this.tb_deposit.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lbl_inptDeposit
            // 
            this.lbl_inptDeposit.AutoSize = true;
            this.lbl_inptDeposit.Location = new System.Drawing.Point(22, 208);
            this.lbl_inptDeposit.Name = "lbl_inptDeposit";
            this.lbl_inptDeposit.Size = new System.Drawing.Size(138, 25);
            this.lbl_inptDeposit.TabIndex = 3;
            this.lbl_inptDeposit.Text = "Input Deposit";
            // 
            // lbl_bank4
            // 
            this.lbl_bank4.AutoSize = true;
            this.lbl_bank4.Font = new System.Drawing.Font("Microsoft YaHei", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bank4.Location = new System.Drawing.Point(135, 35);
            this.lbl_bank4.Name = "lbl_bank4";
            this.lbl_bank4.Size = new System.Drawing.Size(186, 48);
            this.lbl_bank4.TabIndex = 0;
            this.lbl_bank4.Text = "UC BANK";
            // 
            // pnl_tarik
            // 
            this.pnl_tarik.Controls.Add(this.lbl_tarik);
            this.pnl_tarik.Controls.Add(this.tb_tarik);
            this.pnl_tarik.Controls.Add(this.btn_out);
            this.pnl_tarik.Controls.Add(this.btn_tarik);
            this.pnl_tarik.Controls.Add(this.lbl_bank5);
            this.pnl_tarik.Location = new System.Drawing.Point(984, 207);
            this.pnl_tarik.Name = "pnl_tarik";
            this.pnl_tarik.Size = new System.Drawing.Size(480, 441);
            this.pnl_tarik.TabIndex = 5;
            this.pnl_tarik.Visible = false;
            // 
            // lbl_tarik
            // 
            this.lbl_tarik.AutoSize = true;
            this.lbl_tarik.Location = new System.Drawing.Point(17, 231);
            this.lbl_tarik.Name = "lbl_tarik";
            this.lbl_tarik.Size = new System.Drawing.Size(116, 25);
            this.lbl_tarik.TabIndex = 10;
            this.lbl_tarik.Text = "Input Uang";
            // 
            // tb_tarik
            // 
            this.tb_tarik.Location = new System.Drawing.Point(155, 225);
            this.tb_tarik.Name = "tb_tarik";
            this.tb_tarik.Size = new System.Drawing.Size(185, 31);
            this.tb_tarik.TabIndex = 9;
            // 
            // btn_out
            // 
            this.btn_out.Location = new System.Drawing.Point(344, 93);
            this.btn_out.Name = "btn_out";
            this.btn_out.Size = new System.Drawing.Size(102, 47);
            this.btn_out.TabIndex = 7;
            this.btn_out.Text = "Log Out";
            this.btn_out.UseVisualStyleBackColor = true;
            this.btn_out.Click += new System.EventHandler(this.btn_out_Click);
            // 
            // btn_tarik
            // 
            this.btn_tarik.Location = new System.Drawing.Point(182, 294);
            this.btn_tarik.Name = "btn_tarik";
            this.btn_tarik.Size = new System.Drawing.Size(130, 56);
            this.btn_tarik.TabIndex = 5;
            this.btn_tarik.Text = "Withdraw";
            this.btn_tarik.UseVisualStyleBackColor = true;
            this.btn_tarik.Click += new System.EventHandler(this.btn_tarik_Click);
            // 
            // lbl_bank5
            // 
            this.lbl_bank5.AutoSize = true;
            this.lbl_bank5.Font = new System.Drawing.Font("Microsoft YaHei", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bank5.Location = new System.Drawing.Point(135, 35);
            this.lbl_bank5.Name = "lbl_bank5";
            this.lbl_bank5.Size = new System.Drawing.Size(186, 48);
            this.lbl_bank5.TabIndex = 0;
            this.lbl_bank5.Text = "UC BANK";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1678, 996);
            this.Controls.Add(this.pnl_tarik);
            this.Controls.Add(this.pnl_deposit);
            this.Controls.Add(this.pnl_bank);
            this.Controls.Add(this.pnl_register);
            this.Controls.Add(this.pnl_menu);
            this.Name = "Form1";
            this.Text = "UC Bank Simulation";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnl_menu.ResumeLayout(false);
            this.pnl_menu.PerformLayout();
            this.pnl_register.ResumeLayout(false);
            this.pnl_register.PerformLayout();
            this.pnl_bank.ResumeLayout(false);
            this.pnl_bank.PerformLayout();
            this.pnl_deposit.ResumeLayout(false);
            this.pnl_deposit.PerformLayout();
            this.pnl_tarik.ResumeLayout(false);
            this.pnl_tarik.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_menu;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.TextBox tb_Pass;
        private System.Windows.Forms.Label lbl_pass;
        private System.Windows.Forms.TextBox tb_Uname;
        private System.Windows.Forms.Label lbl_Uname;
        private System.Windows.Forms.Label lbl_bank;
        private System.Windows.Forms.Panel pnl_register;
        private System.Windows.Forms.Button btn_register2;
        private System.Windows.Forms.TextBox tb_pass2;
        private System.Windows.Forms.Label lbl_password2;
        private System.Windows.Forms.TextBox tb_Uname2;
        private System.Windows.Forms.Label lbl_Uname2;
        private System.Windows.Forms.Label lbl_bank2;
        private System.Windows.Forms.Panel pnl_bank;
        private System.Windows.Forms.Label lbl_amount;
        private System.Windows.Forms.Button btn_logOut;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Button btn_withdraw;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.Label lbl_bank3;
        private System.Windows.Forms.Panel pnl_deposit;
        private System.Windows.Forms.TextBox tb_deposit;
        private System.Windows.Forms.Label lbl_inptDeposit;
        private System.Windows.Forms.Label lbl_bank4;
        private System.Windows.Forms.Button btn_keluar;
        private System.Windows.Forms.Panel pnl_tarik;
        private System.Windows.Forms.Label lbl_tarik;
        private System.Windows.Forms.TextBox tb_tarik;
        private System.Windows.Forms.Button btn_out;
        private System.Windows.Forms.Button btn_tarik;
        private System.Windows.Forms.Label lbl_bank5;
        private System.Windows.Forms.Button btn_setor;
    }
}

