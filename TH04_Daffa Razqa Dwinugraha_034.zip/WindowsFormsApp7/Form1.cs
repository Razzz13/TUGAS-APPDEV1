﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        DataTable P;
        public Form1()
        {
            InitializeComponent();
            P = new DataTable();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BackColor = Color.Aquamarine;
            P.Columns.Add("Nationality");
            P.Columns.Add("Team");
            P.Columns.Add("BackNumber");
            P.Columns.Add("Name");
            P.Columns.Add("Position");
            P.Rows.Add("England", "Manchester United", "1", "Altay Bayindir", "GK");
            P.Rows.Add("England", "Manchester United", "22", "Tom Heaton", "GK");
            P.Rows.Add("England", "Manchester United", "24", "Andre Onana", "GK");
            P.Rows.Add("England", "Manchester United", "2", "Victor Lindelof", "CB");
            P.Rows.Add("England", "Manchester United", "4", "Harry Maguire", "CB");
            P.Rows.Add("England", "Manchester United", "6", "Lisandro Martinez", "CB");
            P.Rows.Add("England", "Manchester United", "19", "Raphael Varane", "CB");
            P.Rows.Add("England", "Manchester United", "23", "Luke Shaw", "LB");
            P.Rows.Add("England", "Manchester United", "29", "Aaron Wan-Bissaka", "RB");
            P.Rows.Add("England", "Manchester United", "8", "Bruno Fernandes", "CM");
            P.Rows.Add("England", "Manchester United", "7", "Mason Mount", "CM");
            P.Rows.Add("England", "Manchester United", "10", "Marcus Rashford", "CF");
            P.Rows.Add("England", "Manchester United", "11", "Rasmus Hojlund", "CF");
            P.Rows.Add("England", "Manchester United", "8", "Alejandro Garnacho", "CF");
            P.Rows.Add("England", "Manchester United", "21", "Antony", "CF");
            P.Rows.Add("England", "Chelsea", "1", "Robert Sanchez", "GK");
            P.Rows.Add("England", "Chelsea", "13", "Marcus Bettinelli", "GK");
            P.Rows.Add("England", "Chelsea", "28", "Djordje Petrovich", "GK");
            P.Rows.Add("England", "Chelsea", "2", "Axel Disasi", "CB");
            P.Rows.Add("England", "Chelsea", "3", "Marc Cucurella", "RB");
            P.Rows.Add("England", "Chelsea", "5", "Benoit Badiashile", "CB");
            P.Rows.Add("England", "Chelsea", "6", "Thiago Silva", "CB");
            P.Rows.Add("England", "Chelsea", "21", "Ben Chillwell", "LB");
            P.Rows.Add("England", "Chelsea", "8", "Enzo Fernandez", "CM");
            P.Rows.Add("England", "Chelsea", "17", "Carney Chukwuemeka", "CM");
            P.Rows.Add("England", "Chelsea", "23", "Conor Galagher", "CM");
            P.Rows.Add("England", "Chelsea", "25", "Moises Caicedo", "CM");
            P.Rows.Add("England", "Chelsea", "8", "Enzo Fernandez", "CM");
            P.Rows.Add("England", "Chelsea", "7", "Raheem Sterling", "CF");
            P.Rows.Add("England", "Chelsea", "10", "Mykhailo Mudryk", "CF");
            P.Rows.Add("England", "Chelsea", "11", "Noni Madueke", "CF");
            P.Rows.Add("England", "Chelsea", "15", "Nicolas Jackson", "CF");
            P.Rows.Add("England", "Chelsea", "20", "Cole Palmer", "CF");
            P.Rows.Add("England", "Chelsea", "18", "Christopher Nkunku", "CF");
            P.Rows.Add("Spain", "FC Barcelona", "1", "Marc-Andre Ter Stegen", "GK");
            P.Rows.Add("Spain", "FC Barcelona", "13", "Inaki Pena", "GK");
            P.Rows.Add("Spain", "FC Barcelona", "2", "Joao Cancelo", "RB");
            P.Rows.Add("Spain", "FC Barcelona", "3", "Alejandro Balde", "LB");
            P.Rows.Add("Spain", "FC Barcelona", "2", "Ronald Araujo", "CB");
            P.Rows.Add("Spain", "FC Barcelona", "5", "Inigo Martinez", "CB");
            P.Rows.Add("Spain", "FC Barcelona", "15", "Andreas Christensen", "CB");
            P.Rows.Add("Spain", "FC Barcelona", "23", "Jules Kounde", "RB");
            P.Rows.Add("Spain", "FC Barcelona", "6", "Pablo Gavi", "CM");
            P.Rows.Add("Spain", "FC Barcelona", "8", "Pedri", "CM");
            P.Rows.Add("Spain", "FC Barcelona", "21", "Frenkie De Jong", "CM");
            P.Rows.Add("Spain", "FC Barcelona", "22", "Ilkay Gundogan", "CM");
            P.Rows.Add("Spain", "FC Barcelona", "9", "Robert Lewandowski", "CF");
            P.Rows.Add("Spain", "FC Barcelona", "7", "Ferran Torres", "CF");
            P.Rows.Add("Spain", "FC Barcelona", "11", "Raphinha", "CF");
            P.Rows.Add("Spain", "FC Barcelona", "14", "Joao Felix", "CF");
            P.Rows.Add("Spain", "FC Barcelona", "19", "Vitor Roque", "CF");
        }
        private void cb_negara_Click(object sender, EventArgs e)
        {
            for (int i = 1; i < P.Rows.Count; i++)
            {
                if (!cb_negara.Items.Contains(P.Rows[i][0]))
                {
                    cb_negara.Items.Add(P.Rows[i][0]);
                }
            }
        }

        private void cb_negara_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cb_tim.Items.Clear();
            cb_tim.Text = "";
            lb_tim.Items.Clear();
            for (int i = 0; i < P.Rows.Count; i++)
            {
                if (P.Rows[i][0] == cb_negara.SelectedItem)
                {
                    if (!cb_tim.Items.Contains(P.Rows[i][1]))
                    {
                        cb_tim.Items.Add(P.Rows[i][1]);
                    }
                }
            }
        }

        private void cb_tim_SelectionChangeCommitted(object sender, EventArgs e)
        {
            lb_tim.Items.Clear();
            for (int i = 0; i < P.Rows.Count; i++)
            {
                if (P.Rows[i][1] == cb_tim.SelectedItem)
                {
                    lb_tim.Items.Add("(" + P.Rows[i][2] + ") " + P.Rows[i][3] + ". " + P.Rows[i][4]);
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (lb_tim.Items.Count <= 11)
            {
                MessageBox.Show("pemain harus 11 atau lebih!");
            }
            else
            {
                for (int i = 0; i < P.Rows.Count; i++)
                {
                    if (P.Rows[i][1] == cb_tim.SelectedItem)
                    {
                        P.Rows.RemoveAt(lb_tim.SelectedIndex + i);
                        lb_tim.Items.Remove(lb_tim.SelectedItem);
                        break;
                    }
                }
            }
        }

        private void btn_tambah_Click(object sender, EventArgs e)
        {
            if (cb_tim.Text == "")
            {
                MessageBox.Show("Pilih tim");
                return;
            }
            else if (tb_namaPemain.Text == "")
            {
                MessageBox.Show("Isi nama pemain");
                return;
            }
            else if (tb_nopung.Text == "")
            {
                MessageBox.Show("isi nomor punggung");
                return;
            }
            else if (cb_posisi.Text == "")
            {
                MessageBox.Show("Pilih Posisi");
                return;
            }
            else 
            {
                bool benar = false;
                for (int i = 0; i < P.Rows.Count; i++)
                {
                    if (tb_namaPemain.Text == P.Rows[i][3].ToString())
                    {
                        MessageBox.Show("Nama terdaftar sama!");
                        benar = true;
                        break;
                    }
                }
                if (benar == false)
                {
                    P.Rows.Add(cb_negara.SelectedItem.ToString(), cb_tim.SelectedItem.ToString(), tb_nopung.Text.ToString(), tb_namaPemain.Text.ToString(), cb_posisi.SelectedItem.ToString());
                    lb_tim.Items.Clear();
                    for (int i = 0; i < P.Rows.Count; i++)
                    {
                        if (P.Rows[i][1] == cb_tim.SelectedItem)
                        {
                            lb_tim.Items.Add("( " + P.Rows[i][2] + ") " + P.Rows[i][3] + ". " + P.Rows[i][4]);
                        }
                    }
                }
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (tb_namaTim.Text == "")
            {
                MessageBox.Show("Nama tim kosong");
                return;
            }
            else if (tb_Negara.Text == "")
            {
                MessageBox.Show("Nama negara asal kosong");
                return;
            }
            else
            {
                bool benar = false;
                for (int i = 0; i < P.Rows.Count; i++)
                {
                    if (tb_namaTim.Text == P.Rows[i][1].ToString())
                    {
                        MessageBox.Show("nama tim terpakai!");
                        benar = true;
                        break;
                    }
                }
                if (benar == false)
                {
                    P.Rows.Add(tb_Negara.Text, tb_namaTim.Text, "", "", "");
                    tb_namaTim.Clear();
                    tb_Negara.Clear();
                    lb_tim.Items.Clear();
                    cb_negara.Text = "";
                    cb_tim.Items.Clear();
                    cb_tim.Text = "";
                }
            }
        }
    }
}