﻿namespace WindowsFormsApp7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_tim = new System.Windows.Forms.ListBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.lbl_Judul = new System.Windows.Forms.Label();
            this.cb_negara = new System.Windows.Forms.ComboBox();
            this.lbl_negara = new System.Windows.Forms.Label();
            this.lbl_Tim = new System.Windows.Forms.Label();
            this.cb_tim = new System.Windows.Forms.ComboBox();
            this.lbl_namaNegara = new System.Windows.Forms.Label();
            this.lbl_Namatim = new System.Windows.Forms.Label();
            this.lbl_tambahTim = new System.Windows.Forms.Label();
            this.tb_namaTim = new System.Windows.Forms.TextBox();
            this.tb_Negara = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.tb_nopung = new System.Windows.Forms.TextBox();
            this.tb_namaPemain = new System.Windows.Forms.TextBox();
            this.lbl_nopung = new System.Windows.Forms.Label();
            this.lbl_namaPemain = new System.Windows.Forms.Label();
            this.lbl_Tambahpemain = new System.Windows.Forms.Label();
            this.lbl_posisi = new System.Windows.Forms.Label();
            this.cb_posisi = new System.Windows.Forms.ComboBox();
            this.btn_tambah = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_tim
            // 
            this.lb_tim.FormattingEnabled = true;
            this.lb_tim.ItemHeight = 25;
            this.lb_tim.Location = new System.Drawing.Point(3, 1);
            this.lb_tim.Name = "lb_tim";
            this.lb_tim.Size = new System.Drawing.Size(673, 504);
            this.lb_tim.TabIndex = 0;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(29, 525);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(172, 60);
            this.btn_delete.TabIndex = 1;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // lbl_Judul
            // 
            this.lbl_Judul.AutoSize = true;
            this.lbl_Judul.Location = new System.Drawing.Point(732, 27);
            this.lbl_Judul.Name = "lbl_Judul";
            this.lbl_Judul.Size = new System.Drawing.Size(139, 25);
            this.lbl_Judul.TabIndex = 2;
            this.lbl_Judul.Text = "Soccer Team";
            // 
            // cb_negara
            // 
            this.cb_negara.FormattingEnabled = true;
            this.cb_negara.Location = new System.Drawing.Point(929, 88);
            this.cb_negara.Name = "cb_negara";
            this.cb_negara.Size = new System.Drawing.Size(215, 33);
            this.cb_negara.TabIndex = 3;
            this.cb_negara.SelectionChangeCommitted += new System.EventHandler(this.cb_negara_SelectionChangeCommitted);
            this.cb_negara.Click += new System.EventHandler(this.cb_negara_Click);
            // 
            // lbl_negara
            // 
            this.lbl_negara.AutoSize = true;
            this.lbl_negara.Location = new System.Drawing.Point(751, 96);
            this.lbl_negara.Name = "lbl_negara";
            this.lbl_negara.Size = new System.Drawing.Size(129, 25);
            this.lbl_negara.TabIndex = 4;
            this.lbl_negara.Text = "Pilih Negara";
            // 
            // lbl_Tim
            // 
            this.lbl_Tim.AutoSize = true;
            this.lbl_Tim.Location = new System.Drawing.Point(751, 153);
            this.lbl_Tim.Name = "lbl_Tim";
            this.lbl_Tim.Size = new System.Drawing.Size(94, 25);
            this.lbl_Tim.TabIndex = 6;
            this.lbl_Tim.Text = "Pilih Tim";
            // 
            // cb_tim
            // 
            this.cb_tim.FormattingEnabled = true;
            this.cb_tim.Location = new System.Drawing.Point(929, 145);
            this.cb_tim.Name = "cb_tim";
            this.cb_tim.Size = new System.Drawing.Size(215, 33);
            this.cb_tim.TabIndex = 5;
            this.cb_tim.SelectionChangeCommitted += new System.EventHandler(this.cb_tim_SelectionChangeCommitted);
            // 
            // lbl_namaNegara
            // 
            this.lbl_namaNegara.AutoSize = true;
            this.lbl_namaNegara.Location = new System.Drawing.Point(751, 371);
            this.lbl_namaNegara.Name = "lbl_namaNegara";
            this.lbl_namaNegara.Size = new System.Drawing.Size(82, 25);
            this.lbl_namaNegara.TabIndex = 11;
            this.lbl_namaNegara.Text = "Negara";
            // 
            // lbl_Namatim
            // 
            this.lbl_Namatim.AutoSize = true;
            this.lbl_Namatim.Location = new System.Drawing.Point(751, 297);
            this.lbl_Namatim.Name = "lbl_Namatim";
            this.lbl_Namatim.Size = new System.Drawing.Size(109, 25);
            this.lbl_Namatim.TabIndex = 9;
            this.lbl_Namatim.Text = "Nama Tim";
            // 
            // lbl_tambahTim
            // 
            this.lbl_tambahTim.AutoSize = true;
            this.lbl_tambahTim.Location = new System.Drawing.Point(732, 228);
            this.lbl_tambahTim.Name = "lbl_tambahTim";
            this.lbl_tambahTim.Size = new System.Drawing.Size(131, 25);
            this.lbl_tambahTim.TabIndex = 7;
            this.lbl_tambahTim.Text = "Tambah Tim";
            // 
            // tb_namaTim
            // 
            this.tb_namaTim.Location = new System.Drawing.Point(929, 297);
            this.tb_namaTim.Name = "tb_namaTim";
            this.tb_namaTim.Size = new System.Drawing.Size(215, 31);
            this.tb_namaTim.TabIndex = 12;
            // 
            // tb_Negara
            // 
            this.tb_Negara.Location = new System.Drawing.Point(929, 368);
            this.tb_Negara.Name = "tb_Negara";
            this.tb_Negara.Size = new System.Drawing.Size(215, 31);
            this.tb_Negara.TabIndex = 13;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(968, 436);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(121, 58);
            this.btn_add.TabIndex = 14;
            this.btn_add.Text = "Tambah";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // tb_nopung
            // 
            this.tb_nopung.Location = new System.Drawing.Point(929, 675);
            this.tb_nopung.Name = "tb_nopung";
            this.tb_nopung.Size = new System.Drawing.Size(215, 31);
            this.tb_nopung.TabIndex = 19;
            // 
            // tb_namaPemain
            // 
            this.tb_namaPemain.Location = new System.Drawing.Point(929, 604);
            this.tb_namaPemain.Name = "tb_namaPemain";
            this.tb_namaPemain.Size = new System.Drawing.Size(215, 31);
            this.tb_namaPemain.TabIndex = 18;
            // 
            // lbl_nopung
            // 
            this.lbl_nopung.AutoSize = true;
            this.lbl_nopung.Location = new System.Drawing.Point(751, 678);
            this.lbl_nopung.Name = "lbl_nopung";
            this.lbl_nopung.Size = new System.Drawing.Size(75, 25);
            this.lbl_nopung.TabIndex = 17;
            this.lbl_nopung.Text = "Nomor";
            // 
            // lbl_namaPemain
            // 
            this.lbl_namaPemain.AutoSize = true;
            this.lbl_namaPemain.Location = new System.Drawing.Point(751, 604);
            this.lbl_namaPemain.Name = "lbl_namaPemain";
            this.lbl_namaPemain.Size = new System.Drawing.Size(68, 25);
            this.lbl_namaPemain.TabIndex = 16;
            this.lbl_namaPemain.Text = "Nama";
            // 
            // lbl_Tambahpemain
            // 
            this.lbl_Tambahpemain.AutoSize = true;
            this.lbl_Tambahpemain.Location = new System.Drawing.Point(732, 535);
            this.lbl_Tambahpemain.Name = "lbl_Tambahpemain";
            this.lbl_Tambahpemain.Size = new System.Drawing.Size(168, 25);
            this.lbl_Tambahpemain.TabIndex = 15;
            this.lbl_Tambahpemain.Text = "Tambah Pemain";
            // 
            // lbl_posisi
            // 
            this.lbl_posisi.AutoSize = true;
            this.lbl_posisi.Location = new System.Drawing.Point(751, 755);
            this.lbl_posisi.Name = "lbl_posisi";
            this.lbl_posisi.Size = new System.Drawing.Size(70, 25);
            this.lbl_posisi.TabIndex = 21;
            this.lbl_posisi.Text = "Posisi";
            // 
            // cb_posisi
            // 
            this.cb_posisi.FormattingEnabled = true;
            this.cb_posisi.Items.AddRange(new object[] {
            "GK",
            "CB",
            "RB",
            "LB",
            "CM",
            "CF"});
            this.cb_posisi.Location = new System.Drawing.Point(929, 747);
            this.cb_posisi.Name = "cb_posisi";
            this.cb_posisi.Size = new System.Drawing.Size(215, 33);
            this.cb_posisi.TabIndex = 20;
            // 
            // btn_tambah
            // 
            this.btn_tambah.Location = new System.Drawing.Point(976, 824);
            this.btn_tambah.Name = "btn_tambah";
            this.btn_tambah.Size = new System.Drawing.Size(113, 57);
            this.btn_tambah.TabIndex = 22;
            this.btn_tambah.Text = "Tambah";
            this.btn_tambah.UseVisualStyleBackColor = true;
            this.btn_tambah.Click += new System.EventHandler(this.btn_tambah_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1774, 1030);
            this.Controls.Add(this.btn_tambah);
            this.Controls.Add(this.lbl_posisi);
            this.Controls.Add(this.cb_posisi);
            this.Controls.Add(this.tb_nopung);
            this.Controls.Add(this.tb_namaPemain);
            this.Controls.Add(this.lbl_nopung);
            this.Controls.Add(this.lbl_namaPemain);
            this.Controls.Add(this.lbl_Tambahpemain);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.tb_Negara);
            this.Controls.Add(this.tb_namaTim);
            this.Controls.Add(this.lbl_namaNegara);
            this.Controls.Add(this.lbl_Namatim);
            this.Controls.Add(this.lbl_tambahTim);
            this.Controls.Add(this.lbl_Tim);
            this.Controls.Add(this.cb_tim);
            this.Controls.Add(this.lbl_negara);
            this.Controls.Add(this.cb_negara);
            this.Controls.Add(this.lbl_Judul);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.lb_tim);
            this.Name = "Form1";
            this.Text = "Soccer Team Selection";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lb_tim;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Label lbl_Judul;
        private System.Windows.Forms.ComboBox cb_negara;
        private System.Windows.Forms.Label lbl_negara;
        private System.Windows.Forms.Label lbl_Tim;
        private System.Windows.Forms.ComboBox cb_tim;
        private System.Windows.Forms.Label lbl_namaNegara;
        private System.Windows.Forms.Label lbl_Namatim;
        private System.Windows.Forms.Label lbl_tambahTim;
        private System.Windows.Forms.TextBox tb_namaTim;
        private System.Windows.Forms.TextBox tb_Negara;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.TextBox tb_nopung;
        private System.Windows.Forms.TextBox tb_namaPemain;
        private System.Windows.Forms.Label lbl_nopung;
        private System.Windows.Forms.Label lbl_namaPemain;
        private System.Windows.Forms.Label lbl_Tambahpemain;
        private System.Windows.Forms.Label lbl_posisi;
        private System.Windows.Forms.ComboBox cb_posisi;
        private System.Windows.Forms.Button btn_tambah;
    }
}

